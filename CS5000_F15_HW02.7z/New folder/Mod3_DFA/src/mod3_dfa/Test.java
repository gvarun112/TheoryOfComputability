package mod3_dfa;

import java.io.IOException;

public class Test {
    public static void main(String[] args) throws IOException {
        Mod3_DFA m = new Mod3_DFA();
        m.runTests();
    }
}